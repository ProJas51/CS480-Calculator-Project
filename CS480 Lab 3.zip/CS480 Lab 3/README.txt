# CS480-Calculator-Project
Scientific Calculator project made my senior year of College. Advanced Software Engineering class 

Compatability: This program is inteded to use with any modern browser (Google Chrome, Firefox, Edge, Opera, etc). Only browser that doesn't work with it is any broswer not supporting css styling. 

IMPORTANT NOTE: since this program was made with HTML, CSS, and JS, there is no running from command line for this program 

How to Run: Download the Zip file onto your desktop or laptop, and open the folder into your preferred IDE that supports HTML, CSS, and JS code. Double click on the HTML file and the calculator should open in your browser. 

Input is given to the calculator via buttons, and the typed buttons for the equation will show up at the top of the calculator. Once the "=" is pressed, the user inputed expression will be calculated. 

Expressions: This program contains all basic arithmetic operations, and intended use of parenthises, trig functions, logs, and exponents. I preferace "intended," because these functions are not fully functional (RAN OUT OF TIME). 
